const http = require('http');
const fs = require('fs');
const path = require('path');
const port = process.env.PORT || 3000;
const publicFolder = path.join(__dirname, 'public');

const projects = [
  { id: 1, title: 'E-Commerce Platform', type: 'Full Stack', description: 'A responsive shopping platform with a secure checkout flow and product management.', tags: ['Node.js', 'Express', 'MongoDB'] },
  { id: 2, title: 'Task Manager', type: 'Web Application', description: 'A productivity app for creating, organizing, and tracking daily tasks.', tags: ['JavaScript', 'REST API', 'CSS'] },
  { id: 3, title: 'Portfolio Website', type: 'Personal Brand', description: 'A fast, accessible portfolio built to showcase work, skills, and contact details.', tags: ['HTML', 'CSS', 'JavaScript'] }
];

const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript' };
http.createServer((req, res) => {
  if (req.url === '/api/projects') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify(projects));
  }
  const requested = req.url === '/' ? 'index.html' : req.url.split('?')[0];
  const file = path.join(publicFolder, path.basename(requested));
  fs.readFile(file, (error, content) => {
    if (error) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'text/plain' });
    res.end(content);
  });
}).listen(port, () => console.log(`Portfolio running at http://localhost:${port}`));
