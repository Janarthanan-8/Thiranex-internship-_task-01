async function loadProjects() {
  const list = document.querySelector('#project-list');
  try {
    const response = await fetch('/api/projects');
    if (!response.ok) throw new Error('Unable to load projects');
    const projects = await response.json();
    list.innerHTML = projects.map(project => `
      <article class="project-card">
        <div><p class="project-type">${project.type}</p><h3>${project.title}</h3><p>${project.description}</p><div class="tags">${project.tags.map(tag => `<span>${tag}</span>`).join('')}</div></div>
        <span class="arrow">↗</span>
      </article>`).join('');
  } catch (error) {
    list.innerHTML = '<p class="loading">Projects will be available soon.</p>';
  }
}
loadProjects();
